How to run the python program:

There are two python programs that need to be run, Database.py to create the database locally and AprioriCode.py to implement the apriori algorithm on those 5 databases.

Step1:
Run the Database.py to store the 5 databases in your local pc/laptop.

Step2:
Run the AprioriCode.py in the same current working directory so that it can access the database easily and it will print all the output in the console.

Step3:
Run the Brute.py in the same current working directory so that it can access the database easily and it will print all the output in the console.